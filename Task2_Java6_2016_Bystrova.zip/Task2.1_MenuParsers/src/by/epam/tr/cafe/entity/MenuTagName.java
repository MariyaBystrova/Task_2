package by.epam.tr.cafe.entity;

public enum MenuTagName {
	MENU,COLD_SNACK, HOT_SNACK, BREAKFAST, DISH, PHOTO, NAME, DESCRIPTION, PORTION_GRAMS, PRICE
}
