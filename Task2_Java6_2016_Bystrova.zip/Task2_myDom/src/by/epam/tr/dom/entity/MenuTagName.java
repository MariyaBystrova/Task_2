package by.epam.tr.dom.entity;

public enum MenuTagName {
	MENU,COLD_SNACK, HOT_SNACK, BREAKFAST, DISH, PHOTO, NAME, DESCRIPTION, PORTION_GRAMS, PRICE
}
