package by.tc.les03.service;

import by.tc.les03.entity.Document;

public interface DomParser {
	public Document parse(String fileName);
}
